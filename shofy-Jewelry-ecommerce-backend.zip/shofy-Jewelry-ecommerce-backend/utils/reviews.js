const reviews = [
  {
    _id: "6461c46a9154b65448da799f",
    userId: "645f7e130ba9d3c3ea50555a",
    productId: "641e887d05f9ee1717e1348a",
    rating: 5,
    comment: "This is nice product"
  },
  {
    _id: "6461c5b99154b65448da7a38",
    userId: "645f7e130ba9d3c3ea50555a",
    productId: "641e887d05f9ee1717e134c6",
    rating: 4,
    comment: "This is nice product"
  },
  {
    _id: "6461f6098a8552beef539317",
    userId: "6461f490aae01ae021285ecb",
    productId: "641e887d05f9ee1717e134cb",
    rating: 3,
    comment: "Good product"
  },
  {
    _id: "64620d3b8a8552beef5394ca",
    userId: "6461f490aae01ae021285ecb",
    productId: "641e887d05f9ee1717e134cb",
    rating: 5,
    comment: "Awesome"
  },
  {
    _id: "6462f65c5693f23f37e966d9",
    userId: "64621f12c16ce188c0b5cb30",
    productId: "641e887d05f9ee1717e134c6",
    rating: 5,
    comment: "Good"
  },
  {
    _id: "6463026f9eb7e8a0fc8b3457",
    userId: "645f7e130ba9d3c3ea50555a",
    productId: "641e887d05f9ee1717e1349f",
    rating: 5,
    comment: "Average product"
  },
  {
    _id: "646851914edd5c5271092b1d",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "6421258288fba3e101965dc3",
    rating: 4.5,
    comment: "Good product"
  },
  {
    _id: "646851be4edd5c5271092be3",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "64216b0902240f90b1138e8e",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "646851df4edd5c5271092caa",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "6421700802240f90b1138e9e",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "646861ee4edd5c5271092f1d",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "6421650a02240f90b1138e1e",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "6468630e4edd5c527109310d",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "64250d8e253d81bc860d4d26",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "6468633f4edd5c5271093118",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "64251bc0253d81bc860d4db5",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "6468636b4edd5c527109318f",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "6431364df5a812bd37e765ac",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "646863a14edd5c5271093199",
    userId: "6465ac4d3322f9425ac8f444",
    productId: "64313e92f5a812bd37e765cf",
    rating: 4,
    comment: "Good product"
  },
  {
    _id: "646895be5058260f55efbfa6",
    userId: "645f7e130ba9d3c3ea50555a",
    productId: "641e887d05f9ee1717e134b7",
    rating: 4.5,
    comment: "Nice Product"
  }
]

module.exports = reviews;